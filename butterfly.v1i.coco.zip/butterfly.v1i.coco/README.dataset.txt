# butterfly > 2024-11-24 4:46pm
https://universe.roboflow.com/imane-elblage/butterfly-v5npn

Provided by a Roboflow user
License: CC BY 4.0

